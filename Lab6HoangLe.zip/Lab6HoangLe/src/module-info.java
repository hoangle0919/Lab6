/**
 * 
 */
/**
 * 
 */
module Lab6HoangLe {
}