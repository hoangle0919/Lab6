package LAb6;

abstract class AbstractEmployee{ 
	public String name;
	public Jobtype jobtype;
	public double salary;
	
}
