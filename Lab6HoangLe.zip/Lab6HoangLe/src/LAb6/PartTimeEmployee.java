package LAb6;

public class PartTimeEmployee implements EmployeeInterface {
	
	public String name;
	public Jobtype jobtype = Jobtype.PART_TIME;
	public double salary;
	public int hours;
	public double hourlywages;
	
	public double calculateSalary() {
		salary = hours * hourlywages;
		return salary;
	}
	
	public void displayDetails() {
		System.out.println("Name: " + name + " | Job Type: " + jobtype + " | Salary: " + calculateSalary());
		
	}

}
