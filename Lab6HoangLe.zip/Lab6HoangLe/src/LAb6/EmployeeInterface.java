package LAb6;

interface EmployeeInterface {
	double calculateSalary();
	void displayDetails();
}
