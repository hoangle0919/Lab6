package LAb6;

public enum Jobtype {
	FULL_TIME,
	PART_TIME,
	INTERN,
}
