package LAb6;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FullTimeEmployee fulltime = new FullTimeEmployee();
		fulltime.name = "Jack";
		fulltime.salary = 1000000;
		fulltime.bonus = 50;
		
		PartTimeEmployee parttime = new PartTimeEmployee();
		parttime.name = "Jacki";
		parttime.hourlywages = 35;
		parttime.hours = 40;
		
		InternEmployee intern = new InternEmployee();
		intern.name = "Jackie";
		intern.salary = 1000000;
		
		
		
		fulltime.displayDetails();
		parttime.displayDetails();
		intern.displayDetails();
	}

}
