package LAb6;

class FullTimeEmployee implements EmployeeInterface  {
	
	public String name;
	public Jobtype jobtype = Jobtype.FULL_TIME;
	public double salary;
	public double bonus;
	
	public double calculateSalary() {
		salary = salary + bonus;
		return salary;
	}
	
	public void displayDetails() {
		System.out.println("Name: " + name + " | Job Type: " + jobtype + " | Salary: " + salary);
		
	}
	
}
