package LAb6;

public class InternEmployee implements EmployeeInterface {
	
	public String name;
	public Jobtype jobtype = Jobtype.INTERN;
	public double salary;
	
	public double calculateSalary() {
		return salary;
	}
	
	public void displayDetails() {
		System.out.println("Name: " + name + " | Job Type: " + jobtype + " | Salary: " + salary);
	}

}
